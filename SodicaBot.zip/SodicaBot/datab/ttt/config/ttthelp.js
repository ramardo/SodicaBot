const tttayuda = (p) => {
    return `🔥 *TaTeTi Offline* 🔥

Disponible sólo para grupos

¿Cómo se juega?

➻❥ *${p}ttt <dificultad>*

DIFICULTADES:

facil: modo gay

normal: 66% de chance de perder

dificil: 11% de chance de perder

impossible: no podés ganar nunca.

*ℹ️| INFO:*

Podés jugar cada 2 munutos.
En caso de que haya un error o por inactividad, la partida se termina en 2 munutos

CÓMO PONER COORDENADAS:
➻❥ *${p}coord <coordenada>*
EJEMPLO
➻❥ ${p}coord a1
*Una forma más rápida y fácil es solo usar
➻❥ a1


	🌀1️⃣2️⃣3️⃣
	🅰️❌🔲🔲
	🅱️🔲🔲🔲
	©️🔲🔲🔲

VER TU STATUS:
➻❥ *${p}tttme*

RECOMPENSAS:

MODO FÁCIL:
Ganañá: + [ 25 / 50 ]
Perdé: - [ 200 / 200 ]

MODO NORMAL:
Ganá: + [ 75 / 150 ]
Perdé: - [ 75 / 150 ]

MODO DIFÍCIL:
Ganá: + [ 200 / 400 ]
Perdé: - [ 25 / 50 ]

MODO IMPOSIBLE
Ganá: + [ 1000 / 2000 」
Perdé: - [ 0 / 0 」

JUEGO EMPATADO

[ 0 / 0 ]

PARTIDA NO FINALIZADA

Perdés: - [ 75 / 150 ]`
}

exports.tttayuda = tttayuda
