const gitdobot = (prefix) => {
return`
𝚯 𝐐𝐔𝐄 𝐏𝐄𝐍𝐒𝐀 𝐐𝐔𝐄 𝐓𝐀 𝐅𝐀𝐙𝐄𝐍𝐃𝚯?`
}

exports.gitdobot = gitdobot
