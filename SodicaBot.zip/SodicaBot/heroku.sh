git config --global user.email "blablablabla@gmail.com" && git config --global user.name "blabla" && git add . && git commit -m "heroku" && git push heroku master
