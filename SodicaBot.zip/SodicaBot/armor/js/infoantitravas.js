const infoantitravas = (prefix, pushname) => {
return `
Hola ${pushname}

Esta función fue muy difícil de hacer, debería ir en solo para usuarios premiums, pero decidimos ponerlo gratis porque hay muchos kuakers sin atención que atacan grupos porque sí.
Esta función detecta si un mensaje es un binario o no 
⚠️| ADVERTENCIA: *SÓLO DETECTA BINARIOS DE TEXTO* para evitar otros binarios existe el ${prefix}anticatalogo ${prefix}antiaudio ${prefix}antiimagen entre otros.

${prefix}antitravas 1 

1 para activar y 0 para desactivar.

`
}

exports.infoantitravas = infoantitravas