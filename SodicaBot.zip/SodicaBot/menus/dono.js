const menudono = (prefix) => {
	
	
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 	

return `
	
⟪────────⟦   ♠   ⟧────────⟫
 
  㑹────⟬𝐌𝐄𝐍𝐔́ 𝐂𝐑𝐄𝐀𝐃𝐎𝐑⟭────㑹

⛛⚌⚌⚌⚌⎐⚌⚌⚌⚌⚌⚌⚌⎐⚌⚌⚌⚌⛛

║𖣴⋗${prefix}fotomenu
║𖣴⋗${prefix}blockcmd  (cmd)
║𖣴⋗${prefix}unblockcmd (cmd)
║𖣴⋗${prefix}legendabv (oq qr) 
║𖣴⋗${prefix}legendasaiu (oq qr)
║𖣴⋗${prefix}legendasaiu2 (oq qr)
║𖣴⋗${prefix}legendabv2 (oq qr)
║𖣴⋗${prefix}fundobemvindo (img)
║𖣴⋗${prefix}fundosaiu (img)
║𖣴⋗${prefix}serpremium
║𖣴⋗${prefix}listagp
║𖣴⋗${prefix}limparmsg
║𖣴⋗${prefix}antipalavrão 1 / 0
║𖣴⋗${prefix}antiligar 1 / 0
║𖣴⋗${prefix}antipv 1 / 0 
║𖣴⋗${prefix}addpalavra (palabra)
║𖣴⋗${prefix}delpalavra (palabra)
║𖣴⋗${prefix}antipvon
║𖣴⋗${prefix}antipvoff
║𖣴⋗${prefix}ativo
║𖣴⋗${prefix}ausente (txt)
║𖣴⋗${prefix}delpremium
║𖣴⋗${prefix}addpremium
║𖣴⋗${prefix}clonar [@]
║𖣴⋗${prefix}fotobot (img)
║𖣴⋗${prefix}des (nueva descripción)
║𖣴⋗${prefix}limpiar (limpia la conversación)
║𖣴⋗${prefix}block [@] (bloq usuarios) 
║𖣴⋗${prefix}unblock [@] (desbloq usuarios) 
║𖣴⋗${prefix}setprefix
║𖣴⋗${prefix}bangp
║𖣴⋗${prefix}unbangp
║𖣴⋗${prefix}transmitir [txt]

金──────────㑹──────────金
`

}
exports.menudono = menudono







