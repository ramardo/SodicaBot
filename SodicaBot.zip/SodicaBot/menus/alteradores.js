const alteradores = (prefix) => {

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return`
⟪────────⟦🎥│🎶⟧────────⟫
 
  㑹────⟬𝐄𝐃𝐈𝐓𝐎𝐑 𝐃𝐄 𝐕𝐈𝐃𝐄𝐎𝐒⟭────㑹

⛛⚌⚌⚌⚌⎐⚌⚌⚌⚌⚌⚌⚌⚌⎐⚌⚌⚌⚌⛛


㋒════════🎥🎥═════════㋒
║𖣴⋗${prefix}Videolento (responde)
║𖣴⋗${prefix}Videorapido (responde)
║𖣴⋗${prefix}Videocontrario (responde)
㋒════════🎶🎶═════════㋒
║𖣴⋗${prefix}Audiolento (responde)
║𖣴⋗${prefix}Audiorapido (responde)
║𖣴⋗${prefix}Grave (responde)
║𖣴⋗${prefix}Grave2 (responde)
║𖣴⋗${prefix}Esquilo (responde)
║𖣴⋗${prefix}Estourar (responde)
║𖣴⋗${prefix}Bass (responde)
║𖣴⋗${prefix}Bass2 (responde)
║𖣴⋗${prefix}Vozmenino (responde)
金──────────㑹──────────金
`
}

exports.alteradores = alteradores