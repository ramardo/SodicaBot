const menuprem = (prefix) => { 

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return `
⟪──────────⟦   💯   ⟧──────────⟫
 
 㑹─────⟬𝐌𝐄𝐍𝐔 𝐏𝐑𝐄𝐌𝐈𝐔𝐌⟭─────㑹

⛛⚌⚌⚌⚌⚌⎐⚌⚌⚌⚌⚌⚌⚌⚌⎐⚌⚌⚌⚌⚌⛛

║𖣴⋗${prefix}Destrava [anti binarios]
║𖣴⋗${prefix}Destrava2 [segunda opción]
║𖣴⋗${prefix}Ddd (DDD)
║𖣴⋗${prefix}Cep (NÚMERO)
║𖣴⋗${prefix}GerarCPF
║𖣴⋗${prefix}PremiumList [lista de usuarios premium]
║𖣴⋗${prefix}LerFoto (MARCAR)
║𖣴⋗${prefix}EncurtaLink (LINK)
║𖣴⋗${prefix}hentai
║𖣴⋗${prefix}nekos
║𖣴⋗${prefix}metadinha
金───────────㑹───────────金
`
}

exports.menuprem = menuprem