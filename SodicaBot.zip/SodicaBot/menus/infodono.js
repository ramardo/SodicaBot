const infodono = (prefix, numerodn, NomeDoBot) => {

// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.

return`
══════⟬𝐈𝐍𝐅𝐎 𝐂𝐑𝐄𝐀𝐃𝐎𝐑⟭══════

㊊㊐㊋㊌㊍㊎㊏㊑㊒㊓㊔㊕㊖㊅㊆㊈
            
         ⛛𝐏𝐑𝐎𝐏𝐎𝐄𝐓𝐀𝐑𝐈𝐎⛛
        [ wa.me/${numerodn} ]

🐉𝐏𝐑𝐄𝐅𝐈J𝚯🐉: ${prefix}

👿𝕭𝚹𝐓👿:${NomeDoBot}

㊊㊐㊋㊌㊍㊎㊏㊑㊒㊓㊔㊕㊖㊅㊆㊈
                                  
═══⟬🏮 ⃟ ⃟𝐑𝐚𝐦𝐚𝐓𝐰𝐨㍈ ⃟🏮⟭═══
`
}

exports.infodono = infodono