const cmd_termux = (prefix) => {
return `𝚯 𝐐𝐔𝐄 𝐏𝐄𝐍𝐒𝐀 𝐐𝐔𝐄 𝐓𝐀 𝐅𝐀𝐙𝐄𝐍𝐃𝚯?`
}

exports.cmd_termux = cmd_termux
