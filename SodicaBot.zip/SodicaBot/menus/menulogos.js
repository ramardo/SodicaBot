const menulogos = (prefix) => {
  
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
  return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​

 ⟪────────⟦   😈   ⟧────────⟫
 
  㑹────⟬𝐌𝐄𝐍𝐔 𝐋𝐎𝐆𝚯𝐒⟭────㑹

⛛⚌⚌⚌⚌⎐⚌⚌⚌⚌⚌⚌⚌⎐⚌⚌⚌⚌⛛


╓────⟦𝐍𝐒𝐅𝐖⟧
║                                           
║𖣴⋗${prefix}Plaq
║𖣴⋗${prefix}Plaq2
║𖣴⋗${prefix}Plaq3
║𖣴⋗${prefix}Plaq4
║𖣴⋗${prefix}Plaq5
║
╟──⟦𝐋𝐎𝐆𝐎𝐒 𝐃𝐄 𝟐 𝐓𝐄𝐗𝐓𝐎𝐒⟧
║              
║𖣴⋗${prefix}Comporn (txt/txt) 
║𖣴⋗${prefix}Glitch (txt/txt)
║𖣴⋗${prefix}Glitch3 (txt/txt)
║𖣴⋗${prefix}Grafity (txt-txt)
║𖣴⋗${prefix}Space (txt/txt)
║𖣴⋗${prefix}Marvel (txt/txt)
║𖣴⋗${prefix}GamePlay (txt/txt)
║𖣴⋗${prefix}Stone (txt/txt)
║𖣴⋗${prefix}Steel (txt/txt)
║𖣴⋗${prefix}Ffbanner (txt/txt) 
║𖣴⋗${prefix}Mascoteavatar (txt/txt) 
║
╟──⟦𝐋𝚯𝐆𝚯𝐒 𝐃𝐄 𝟏 𝐓𝐄𝐗𝐓𝚯⟧
║                
║𖣴⋗${prefix}Txtquadrinhos (txt) 
║𖣴⋗${prefix}HackNeon (txt) 
║𖣴⋗${prefix}EquipeMascote (txt) 
║𖣴⋗${prefix}FFavatar (txt) 
║𖣴⋗${prefix}Gizquadro (txt) 
║𖣴⋗${prefix}Angelglx (txt) 
║𖣴⋗${prefix}WingEffect (txt) 
║𖣴⋗${prefix}Angelwing (txt) 
║𖣴⋗${prefix}Blackpink (txt) 
║𖣴⋗${prefix}Girlmascote (txt) 
║𖣴⋗${prefix}Mascotegame (txt) 
║𖣴⋗${prefix}Fpsmascote (txt) 
║𖣴⋗${prefix}Logogame (txt) 
║𖣴⋗${prefix}Glitch2 (txt) 
║𖣴⋗${prefix}3DGold (txt)
║𖣴⋗${prefix}Placaloli (txt)
║𖣴⋗${prefix}Phadow (txt)
║𖣴⋗${prefix}Efeitoneon (txt)
║𖣴⋗${prefix}Cemiterio (txt)
║𖣴⋗${prefix}Metalgold (txt)
║𖣴⋗${prefix}Narutologo (txt)
║𖣴⋗${prefix}Fire (txt)
║𖣴⋗${prefix}Romantic (txt)
║𖣴⋗${prefix}Smoke (txt)
║𖣴⋗${prefix}Papel (txt)
║𖣴⋗${prefix}Lovemsg (txt)
║𖣴⋗${prefix}Lovemsg2 (txt)
║𖣴⋗${prefix}Lovemsg3 (txt)
║𖣴⋗${prefix}Coffecup (txt)
║𖣴⋗${prefix}Coffecup2 (txt)
║𖣴⋗${prefix}Cup (txt)
║𖣴⋗${prefix}Florwooden (txt)
║𖣴⋗${prefix}Lobometal (txt)
║𖣴⋗${prefix}Harryp (txt)
║𖣴⋗${prefix}Txtborboleta (txt)
║𖣴⋗${prefix}Madeira (txt)
║𖣴⋗${prefix}Pornhub (txt)
║𖣴⋗${prefix}Escudo (txt)
║𖣴⋗${prefix}Transformer (txt)
║𖣴⋗${prefix}America (txt)
║𖣴⋗${prefix}Demongreen (txt)
║𖣴⋗${prefix}Wetglass (txt)    
║𖣴⋗${prefix}Toxic (txt)     
║𖣴⋗${prefix}Neon3 (txt)   
║𖣴⋗${prefix}Neondevil (txt) 
║𖣴⋗${prefix}Neongreen (txt)
║𖣴⋗${prefix}Lava (txt)
║𖣴⋗${prefix}Halloween (txt)
║𖣴⋗${prefix}Neondevil (txt)
║𖣴⋗${prefix}DemonFire (txt)
║𖣴⋗${prefix}DemonGreen (txt)
║𖣴⋗${prefix}Thunderv2 (txt)
║𖣴⋗${prefix}Thunder (txt)
║𖣴⋗${prefix}Colaq (txt)
║𖣴⋗${prefix}Luxury (txt)
║𖣴⋗${prefix}Berry (txt)
║𖣴⋗${prefix}Transformer (txt)
║𖣴⋗${prefix}Matrix (txt)
║𖣴⋗${prefix}Horror (txt)
║𖣴⋗${prefix}Nuvem (txt)
║𖣴⋗${prefix}Neon (txt)
║𖣴⋗${prefix}Neon1 (txt)
║𖣴⋗${prefix}Neon2 (txt)
║𖣴⋗${prefix}Neon3d (txt)
║𖣴⋗${prefix}NeonGreen (txt)
║𖣴⋗${prefix}Neon3 (txt)
║𖣴⋗${prefix}Neve (txt)
║𖣴⋗${prefix}Areia (txt)
║𖣴⋗${prefix}Vidro (txt)
║𖣴⋗${prefix}Style (txt)
║𖣴⋗${prefix}Pink (txt)
║𖣴⋗${prefix}Carbon (txt)
║𖣴⋗${prefix}Tetalblue (txt)
║𖣴⋗${prefix}Toxic (txt)
║𖣴⋗${prefix}Jeans (txt)
║𖣴⋗${prefix}Ossos (txt)
║𖣴⋗${prefix}Asfalto (txt)
║𖣴⋗${prefix}Natal (txt)
║𖣴⋗${prefix}Joker (txt)
║𖣴⋗${prefix}Blood (txt)
║𖣴⋗${prefix}Break (txt)
║𖣴⋗${prefix}Fiction (txt)
║𖣴⋗${prefix}3dstone (txt)
║𖣴⋗${prefix}Lapis (txt)
║𖣴⋗${prefix}Gelo (txt)
║𖣴⋗${prefix}Rainbow (txt)
║𖣴⋗${prefix}Metalfire (txt)
║
金──────────㑹──────────金`
}

exports.menulogos = menulogos

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 