const menu = (prefix, NomeDoBot) => {
  
// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta creador, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
金────────㑹────────金
               ${NomeDoBot}             
金────────㑹────────金
                                             
╓▱▱▱▱▱▱⛩️▱▱▱▱▱▱╖
   ⾕──⟬𝐁𝐈𝐄𝐍𝐕𝐄𝐍𝐈𝐃𝐎⟭──⾕
╙▱▱▱▱▱▱ 〄 ▱▱▱▱▱▱╜

 ⚏⚏⚏⚏⚏ ⛛ ⚏平⚏ ⛛ ⚏⚏⚏⚏⚏
                𝐌𝐄𝐍𝐔́ 𝐑𝐀́𝐏𝐈𝐃𝐎         
   📌𝗔𝗧𝗘𝗡𝗖𝗜𝗢́𝗡: PARA QUE VEAS CORRECTAMENTE LO QUE HAGO, DEBÉS TENER UN ANDROID MAYOR AL 8.0, DE LO CONTRARIO, ALGUNOS DÍGITOS NO APARECERÁN.  
 金────────㑹────────金
║𖣴⋗${prefix}Menu2 [segundo menú]
║𖣴⋗${prefix}Menudono [menú del creador]
║𖣴⋗${prefix}Efectoimagen [efecto imágenes]
║𖣴⋗${prefix}Menuadm [menú de administradores]
║𖣴⋗${prefix}Menupremium [para usuarios premium]
║𖣴⋗${prefix}Logos [creador de logos
║𖣴⋗${prefix}Comedia [menú divertido]
║𖣴⋗${prefix}Alteradores [editor de videos]

 ⚏⚏⚏⚏⚏ ⛛ ⚏平⚏ ⛛ ⚏⚏⚏⚏⚏
        𝐌𝐄𝐍𝐔́ 𝐌𝐈𝐄𝐌𝐁𝐑𝐎𝐒
 金────────㑹────────金

║𖣴⋗${prefix}Infobot [mi info]
║𖣴⋗${prefix}Idiomas [crear audios]
║𖣴⋗${prefix}Bug [reportar un bug del bot]
║𖣴⋗${prefix}Sugestao [envía una sugerencia]
║𖣴⋗${prefix}Avalie [da las gracias al creador] 

 ⚏⚏⚏⚏⚏ ⛛ ⚏平⚏ ⛛ ⚏⚏⚏⚏⚏
         𝐌𝐄𝐍𝐔́ 𝐂𝐑𝐄𝐀𝐃𝐎𝐑          
 金────────㑹────────金

║𖣴⋗${prefix}Fotomenu (MARCAR-IMG) 
║𖣴⋗${prefix}Gifmenu (MARCAR) 
║𖣴⋗${prefix}InfoBemvindo
║𖣴⋗${prefix}Infopalavrão
║𖣴⋗${prefix}Infolistanegra
║𖣴⋗${prefix}Infobancarac
║𖣴⋗${prefix}Infovotação
║𖣴⋗${prefix}Infocontador
║𖣴⋗${prefix}Infosorteio

 ⚏⚏⚏⚏⚏ ⛛ ⚏平⚏ ⛛ ⚏⚏⚏⚏⚏
        𝐃𝐄𝐒𝐂𝐀𝐑𝐆𝐀𝐑 𝐆𝐑𝐀𝐓𝐈𝐒      
 金────────㑹────────金
 
║𖣴⋗${prefix}Play (NOME) 
║𖣴⋗${prefix}Playmp4 (NOME) 
║𖣴⋗${prefix}Ytsearch (NOME) 
║𖣴⋗${prefix}gimage (NOME)
║𖣴⋗${prefix}Pinterest (NOME)
║𖣴⋗${prefix}print (LINK)
║𖣴⋗${prefix}Ytmp4 (LINK) 
║𖣴⋗${prefix}Ytmp3 (LINK) 
║𖣴⋗${prefix}Tiktok (LINK) 
║𖣴⋗${prefix}Instadw (LINK) 
║𖣴⋗${prefix}Twitter (LINK) 
║𖣴⋗${prefix}Imgpralink (MARCAR)
║𖣴⋗${prefix}Videopralink (MARCAR-V) 

 ⚏⚏⚏⚏⚏ ⛛ ⚏平⚏ ⛛ ⚏⚏⚏⚏⚏
                      𝐉𝐔𝐄𝐆𝐎𝐒                  
 金────────㑹────────金

║𖣴⋗${prefix}Ppt (PEDRA/PAPEL/TESOURA) 
║𖣴⋗${prefix}Tateti (@MENCIONAR A ALGUIEN) 
║𖣴⋗${prefix}Ttt (JUGAR AL TATETI CON EL BOT) 
║𖣴⋗${prefix}Casino (JUGÁ AL CASINO)
║𖣴⋗${prefix}Quizanime 1 / 0
║𖣴⋗${prefix}Quizanimais 1 / 0
║𖣴⋗${prefix}Anagrama 1 / 0

 ⚏⚏⚏⚏⚏ ⛛ ⚏平⚏ ⛛ ⚏⚏⚏⚏⚏
                 𝐒𝐓𝐈𝐂𝐊𝐄𝐑𝐒            
 金────────㑹────────金

║𖣴⋗${prefix}Attp (TEXTO)
║𖣴⋗${prefix}Ttp (TEXTO)
║𖣴⋗${prefix}Fsticker (MARCAR-FOTO)
║𖣴⋗${prefix}Sticker (MARCAR-FOTO)
║𖣴⋗${prefix}Toimg (MARCAR-FIGU)
║𖣴⋗${prefix}Togif (MARCAR-FIGU)
║𖣴⋗${prefix}Afanar (TEXT/TEXT) [roba stickers]
║𖣴⋗${prefix}Packfigu

 ⚏⚏⚏⚏⚏ ⛛ ⚏平⚏ ⛛ ⚏⚏⚏⚏⚏
           𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐂𝐈𝐎́𝐍 
 金────────㑹────────金

║𖣴⋗${prefix}Ping (VELO) 
║𖣴⋗${prefix}Atividade
║𖣴⋗${prefix}Rankativo
║𖣴⋗${prefix}Checkativo (@MARCAR)
║𖣴⋗${prefix}Ranklevel (DE-TODOS) 

 ⚏⚏⚏⚏⚏ ⛛ ⚏平⚏ ⛛ ⚏⚏⚏⚏⚏
       𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 𝐁𝐀́𝐒𝐈𝐂𝐎𝐒     
 金────────㑹────────金
 
║𖣴⋗${prefix}Di (idioma) + (texto) (usa ${prefix}di si no sabés usarlo)
║𖣴⋗${prefix}Traducir Hello [traduce algo]
║𖣴⋗${prefix}Tagme [te menciona]
║𖣴⋗${prefix}Emoji [emoji to sticker]
║𖣴⋗${prefix}Emojimix [mezcla emojis (solo caras)]
║𖣴⋗${prefix}Tabela (txt) [crea un nombre kuaker]
║𖣴⋗${prefix}Conselhobiblico [da un versículo]
║𖣴⋗${prefix}Simi (txt) [habla con simsimi]  
║𖣴⋗${prefix}Perfil [tu perfil]
║𖣴⋗${prefix}Frases
║𖣴⋗${prefix}Calcular (1 + 1)
║𖣴⋗${prefix}Crearnick (txt)
║𖣴⋗${prefix}Dolor
金──────────㑹──────────金

`
}

exports.menu = menu

// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta creador, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.
