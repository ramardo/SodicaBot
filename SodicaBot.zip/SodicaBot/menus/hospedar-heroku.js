const hentai = (prefix) => {
return `𝐅𝐀𝐋𝐄 𝐂𝚯𝐌 𝐌𝐄𝐔 𝐒𝐄𝐍𝐒𝐄𝐈🥷`
}

exports.hentai = hentai
