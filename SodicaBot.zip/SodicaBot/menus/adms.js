const adms = (prefix) => { 
 
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

	return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
	
⟪────────⟦   🥷   ⟧────────⟫
 
 㑹─────⟬𝐌𝐄𝐍𝐔 𝐀𝐃𝐌⟭─────㑹

⛛⚌⚌⚌⚌⎐⚌⚌⚌⚌⚌⚌⚌⎐⚌⚌⚌⚌⛛

║𖣴⋗${prefix}Kick [@menciona] [para sacar]
║𖣴⋗${prefix}Ban (responder mensaje)
║𖣴⋗${prefix}edo-tensei (responder-mensaje)
║𖣴⋗${prefix}Promover [@] (hacer admin)
║𖣴⋗${prefix}Rebaixar [@] (sacar admin)
║𖣴⋗${prefix}Totag (menciona algo)
║𖣴⋗${prefix}Grupo f/a [f: cerrado a:abierto]
║𖣴⋗${prefix}opentime (abrir grupo en tal tiempo)
║𖣴⋗${prefix}closetime (cerrar grupo en tal tiempo)
║𖣴⋗${prefix}Status (Status de la protección)
║𖣴⋗${prefix}Limpiar (anti binarios)
║𖣴⋗${prefix}Atividades (status de mensajes y comandos)
║𖣴⋗${prefix}Linkgp [muestra el link del grupo]
║𖣴⋗${prefix}redefinir [generar nuevo link]
║𖣴⋗${prefix}Grupoinfo (info del grupo)
║𖣴⋗${prefix}Hidetag (txt) (mencionar)
║𖣴⋗${prefix}Marcar [menciona a todos los del grupo]
║𖣴⋗${prefix}Marcar2 [menciona a todos con Wa.me/]
║𖣴⋗${prefix}Anagrama 1 / 0
║𖣴⋗${prefix}Autofigu 1 / 0
║𖣴⋗${prefix}Antidocumento 1 / 0  
║𖣴⋗${prefix}Antiloc 1 / 0  
║𖣴⋗${prefix}Anticontato 1 / 0  
║𖣴⋗${prefix}Antilink 1 / 0
║𖣴⋗${prefix}Antilinkhard 1 / 0
║𖣴⋗${prefix}AntiCatalogo 1 / 0
║𖣴⋗${prefix}Gp 1 / 0
║𖣴⋗${prefix}Bemvindo 1 / 0
║𖣴⋗${prefix}Antiimg 1 / 0
║𖣴⋗${prefix}Antiaudio 1 / 0
║𖣴⋗${prefix}Antivideo 1 / 0
║𖣴⋗${prefix}Leveling 1 / 0  
║𖣴⋗${prefix}Simih 1 / 0
║𖣴⋗${prefix}Simih2 1 / 0
║𖣴⋗${prefix}Fotogp (responder foto) [la foto se convierte en el icono del grupo]
║𖣴⋗${prefix}Descgp (nueva descripción)
║𖣴⋗${prefix}Nomegp (nuevo nombre)
║𖣴⋗${prefix}Criartabela (escribir algo)
║𖣴⋗${prefix}Tabelagp [muestra lo que escribiste en el anterior)

金─────────㑹─────────金


`
}

exports.adms = adms

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 